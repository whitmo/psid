"""The namespace for the pavement to run in, also imports default tasks."""

from paver.runtime import *
from paver.misctasks import *
from paver import setuputils
